export const checkBox = [
    'Funderal home',
    'My home',
    'My place of worship',
    'My favorite bar',
    'Somewhere outside',
    'Other',
];

export const list = [
    'An amusement park!',
    'I don\'t care as long as it\'s someplace casual, like a restaurant with a fun ambiance.',
    'A place with an ocean view.',
    'I want it to be held in New York, not in Florida',                                                                             
]